/* ============================================================
   FSD-X Checkout Gate
   Intercepts clicks on any whop.com/checkout link, shows a
   Terms-of-Service consent modal, and only proceeds after the
   user checks "I understand and agree."

   Usage:
     <script src="checkout-gate.js?v=20260913b"></script>
   Per-product terms:
     Default = membership terms.
     Add data-gate="autotrader" to a checkout link for the
     heavier Auto-Trader terms.
   ============================================================ */
(function () {
  "use strict";

  // ---- Checkout-intent beacon ----
  // Fires once per session the moment a visitor accepts the terms and clicks
  // "Proceed to Checkout". Non-members only, so it lines up 1:1 with the
  // non-member visit counts in the admin Traffic tab. It reuses the same
  // /api/track endpoint as nav-loader.js and posts a synthetic path, so it
  // shows up in "Pages Visited This Month" under /checkout-started.
  // Two pings, both to the same /api/track endpoint as nav-loader.js:
  //
  //  1. /checkout-started — the funnel number. Non-members only, once per
  //     session, so it lines up with the non-member visit counts. Unchanged.
  //
  //  2. /checkout/<product> — once per product per session, members INCLUDED.
  //     The old single ping skipped anyone logged in, so an existing Knightfall
  //     member buying Raven or Nightwing never counted anywhere, and a visitor
  //     who checked out two products in one session counted once.
  //
  // Both carry the session's real source (set by nav-loader.js) instead of a
  // hardcoded 'direct'.
  function ping(paths) {
    var src = "direct", ctx = {};
    try { src = sessionStorage.getItem("fsdx_src") || "direct"; ctx = JSON.parse(sessionStorage.getItem("fsdx_ctx") || "{}") || {}; } catch (e) {}
    // One request for all paths: the Worker does read-modify-write on one daily
    // KV key, so two pings fired at once race and one gets dropped.
    fetch("https://nexus-validator.dfuentes4211.workers.dev/api/track", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ v: ctx.sid ? 2 : 1, source: ctx.src || src, path: paths[0], paths: paths.slice(1), visit: false,
        sid: ctx.sid, camp: ctx.camp, land: ctx.land, ref: ctx.ref, ret: ctx.ret }),
      keepalive: true
    }).catch(function () {});
  }

  function trackCheckoutStart(product) {
    try {
      product = String(product || "membership").toLowerCase().replace(/[^a-z0-9-]/g, "").slice(0, 30) || "membership";
      var paths = [];
      // Funnel number first — non-members, once per session (unchanged).
      if (!localStorage.getItem("fsdx_token") && !sessionStorage.getItem("fsdx_checkout_started")) {
        sessionStorage.setItem("fsdx_checkout_started", "1");
        paths.push("/checkout-started");
      }
      // Per-product — once per product per session, members included.
      var pk = "fsdx_checkout:" + product;
      if (!sessionStorage.getItem(pk)) {
        sessionStorage.setItem(pk, "1");
        paths.push("/checkout/" + product);
      }
      if (paths.length) ping(paths);
    } catch (e) { /* tracking never blocks checkout */ }
  }

  // ---- ONE membership, ONE gate ----
  // Everything is now a single FSD-X membership — the full indicator suite,
  // Strategy Optimizer, Nexus, alerts, the live trade room, and the ORB
  // Auto-Trader — so every checkout shows the SAME unified terms. All
  // data-gate values (membership / tools / autotrader) alias to UNIFIED,
  // so no link can surface mismatched or legacy ("Plus") terms.
  var UNIFIED = {
    eyebrow: "Before You Continue",
    title: "FSD-X Membership — Terms of Service",
    points: [
      "This is one FSD-X membership covering everything — the full indicator suite, Strategy Optimizer, Nexus, alerts, the live trade room, and the ORB Auto-Trader. All of it is <strong>educational, rules-based software — not financial advice</strong> and not a trade-signal service.",
      "Trading involves <strong>substantial risk</strong>; you can lose some or all of your capital. No profit, outcome, or result is guaranteed — the tools assist your process, they do not guarantee performance.",
      "The Auto-Trader <strong>emits automation alerts only — it does not place or guarantee any order</strong>. All execution happens through third-party services and brokers <strong>you</strong> select, configure, and control.",
      "FSD-X is <strong>not responsible</strong> for those third parties — their reliability, fills, latency, or outages — or for any activity once the Auto-Trader is running on your account. A missed, delayed, or failed alert can leave unintended open positions, so <strong>you are responsible for your own safeguards</strong> (broker-side stop, end-of-day flatten, risk limits) and for monitoring your account.",
      "<strong>You</strong> are responsible for confirming automated trading is permitted by your broker and prop firm and for complying with their rules. Validate on a <strong>demo/paper account</strong> before any live use.",
      "Once a billing cycle begins, <strong>all fees are non-refundable</strong>. Cancel during any free trial to avoid being charged.",
      "Access is limited to <strong>one Discord and one TradingView account</strong>. Sharing, reselling, or redistributing access is prohibited and may end access without refund.",
      "<strong>By purchasing and accepting these terms, you take full responsibility for all trades, positions, losses, and outcomes on your account.</strong> Once accepted, that responsibility is yours — FSD-X has no liability for any result.",
      "I have read and agree to the full <a href='disclosures.html' target='_blank' rel='noopener' class='text-green-400 underline hover:text-green-300'>Disclosures &amp; Terms of Service</a>, including the Auto-Trader Addendum."
    ],
    agree: "I accept the FSD-X Membership Terms — including the Auto-Trader Addendum — and take full responsibility for all activity, losses, and outcomes on my own account. FSD-X is not liable for any result.",
    proceed: "Proceed to Checkout"
  };

  /* ---- Nightwing — the entry tier, and a genuinely different product ----
     Site access + Nexus. No indicator suite, no Auto-Trader, no
     live room. Showing a Nightwing buyer the UNIFIED terms above would have
     them agree to an Auto-Trader Addendum for software they are not being
     sold — which is worse than no terms at all, because it misdescribes the
     purchase at the point of sale. So it gets its own set: same risk,
     refund, and one-account language, nothing about automation. */
  var NIGHTWING = {
    eyebrow: "Before You Continue",
    title: "FSD-X Nightwing — Terms of Service",
    points: [
      "Nightwing is <strong>site access and the Nexus 2.0 extension</strong> — the member dashboard, trade journal, backtest workspace, playbook, trade importer and account tracker. It is <strong>educational, rules-based software — not financial advice</strong> and not a trade-signal service.",
      "Nightwing <strong>does not include</strong> the FSD-X indicator suite (ORB PRO / Knightfall MK2, Stack V1, Volume Engine), the Auto-Trader, the live trade room, the VIP Discord channels, or the monthly one-on-one call. Those are part of the full FSD-X membership.",
      "Trading involves <strong>substantial risk</strong>; you can lose some or all of your capital. No profit, outcome, or result is guaranteed — these tools record and analyse your own trading, they do not produce performance.",
      "Any figures, backtests, or historical results shown on this site are <strong>hypothetical</strong> and are not a representation that any account will achieve similar results.",
      "<strong>You</strong> remain responsible for every trade, position, loss, and outcome on your own account. Nothing in the platform places, sizes, or manages an order for you.",
      "Once a billing cycle begins, <strong>all fees are non-refundable</strong>. If your plan includes a free trial, cancel before it ends to avoid being charged; plans without a trial bill immediately.",
      "Access is limited to <strong>one account</strong>. Sharing, reselling, or redistributing access is prohibited and may end access without refund.",
      "I have read and agree to the full <a href='disclosures.html' target='_blank' rel='noopener' class='text-green-400 underline hover:text-green-300'>Disclosures &amp; Terms of Service</a>."
    ],
    agree: "I accept the FSD-X Nightwing Terms and take full responsibility for all activity, losses, and outcomes on my own account. FSD-X is not liable for any result.",
    proceed: "Continue to Checkout"
  };

  /* ---- Raven — the middle tier ----
     Raven, Nexus and the platform. Same reasoning as Nightwing: showing a
     Raven buyer the UNIFIED terms would have them accept an Auto-Trader
     Addendum for software they are not being sold. It also needs one point
     Nightwing does not — Raven produces no performance data of any kind, and
     the Knightfall backtest is not its backtest. Saying so at the point of
     sale is the cheapest protection against a "but the site said" dispute. */
  var RAVEN = {
    eyebrow: "Before You Continue",
    title: "FSD-X Raven — Terms of Service",
    points: [
      "Raven is the <strong>ORB Raven indicator</strong> plus the Nexus 2.0 extension and the member platform. The indicator marks opening range breakouts and draws the levels; it is <strong>educational, rules-based software — not financial advice</strong> and not a trade-signal service.",
      "Raven <strong>applies no grading and no filtering</strong>. It marks every breakout and does not tell you which are worth taking. It does not know whether a level was hit, does not track trades, and reports <strong>no win rate and no performance of any kind</strong>.",
      "<strong>Raven has no backtest and no track record.</strong> Any backtest, figures or historical results shown elsewhere on this site belong to ORB PRO (Knightfall), a different product with grading and filtering that Raven does not have. They are <strong>hypothetical</strong> and are not a representation that any account will achieve similar results.",
      "Raven <strong>does not include</strong> ORB PRO (Knightfall), the Auto-Trader, Stack V1, the Volume Engine, the live trade room, or the VIP Discord channels. Those are part of the full FSD-X membership.",
      "Trading involves <strong>substantial risk</strong>; you can lose some or all of your capital. No profit, outcome, or result is guaranteed.",
      "<strong>You</strong> remain responsible for every trade, position, loss, and outcome on your own account. Nothing in Raven places, sizes, or manages an order for you, and it does not connect to a broker.",
      "Once a billing cycle begins, <strong>all fees are non-refundable</strong>. If your plan includes a free trial, cancel before it ends to avoid being charged; plans without a trial bill immediately.",
      "Access is limited to <strong>one account</strong>, and the TradingView script is granted to <strong>one TradingView username</strong>. Sharing, reselling, or redistributing access is prohibited and may end access without refund.",
      "I have read and agree to the full <a href='disclosures.html' target='_blank' rel='noopener' class='text-green-400 underline hover:text-green-300'>Disclosures &amp; Terms of Service</a>."
    ],
    agree: "I accept the FSD-X Raven Terms and take full responsibility for all activity, losses, and outcomes on my own account. FSD-X is not liable for any result.",
    proceed: "Continue to Checkout"
  };

  /* ---- Knightfall NT8 standalone ----
     Knightfall on NinjaTrader 8 plus the platform and Nexus. Unlike Nightwing
     and Raven this product CAN place orders (Auto Trade), so it carries the
     automation language — rewritten for NinjaTrader, where there is no
     webhook or bridge and the strategy itself submits the order. */
  var NTSOLO = {
    eyebrow: "Before You Continue",
    title: "Knightfall for NinjaTrader 8 — Terms of Service",
    points: [
      "Knightfall for NinjaTrader 8 is the <strong>ORB PRO (Knightfall) strategy for NinjaTrader 8</strong>, plus the Nexus 2.0 extension and the member platform. It is <strong>educational, rules-based software — not financial advice</strong> and not a trade-signal service.",
      "It <strong>does not include</strong> the TradingView scripts, the TradingView Auto-Trader, Stack V1, the Volume Engine, the live trade room, the VIP Discord channels, or the monthly one-on-one call. Those are part of the full FSD-X membership.",
      "With <strong>Auto Trade on, the strategy places and manages orders</strong> in the NinjaTrader account you select. <strong>You</strong> choose that account, the risk setting and the daily loss limit, and you are responsible for monitoring it. Run it on a sim account first.",
      "<strong>You</strong> are responsible for confirming that automated trading is allowed by your broker and prop firm. Rules vary and change.",
      "Trading involves <strong>substantial risk</strong>; you can lose some or all of your capital. No profit, outcome, or result is guaranteed. Software, data feeds, connections and platforms can fail.",
      "Any backtest, figures or historical results shown on this site are <strong>hypothetical</strong> and are not a representation that any account will achieve similar results.",
      "Your license is tied to the <strong>email you log into NinjaTrader with</strong>, entered at checkout. Access is limited to <strong>one person</strong>; sharing, reselling, or redistributing it ends access without refund.",
      "Once a billing cycle begins, <strong>all fees are non-refundable</strong>. If your plan includes a free trial, cancel before it ends to avoid being charged; plans without a trial bill immediately.",
      "I have read and agree to the full <a href='disclosures.html' target='_blank' rel='noopener' class='text-green-400 underline hover:text-green-300'>Disclosures &amp; Terms of Service</a>."
    ],
    agree: "I accept the Knightfall for NinjaTrader 8 Terms and take full responsibility for all activity, losses, and outcomes on my own account, including any orders the strategy places. FSD-X is not liable for any result.",
    proceed: "Continue to Checkout"
  };

  /* ---- Lifetime — one-time, capped, TradingView transition (Oct 2026) ----
     Same product as the membership, so the Auto-Trader language stays. What
     changes is the money: one payment, no trial, no refund, and a plain
     statement of what "lifetime" does and does not cover. */
  var LIFETIME = {
    eyebrow: "Before You Continue",
    title: "FSD-X Lifetime Access — Terms of Service",
    points: [
      "Lifetime Access is a <strong>one-time payment of $399</strong>. There is <strong>no free trial</strong> and the payment is <strong>non-refundable</strong>.",
      "It covers <strong>everything in the FSD-X Pro membership as it exists today</strong> — the indicator suite on TradingView, the Auto-Trader, Nexus 2.0, the member platform, the VIP Discord and live room, and the monthly one-on-one call — for as long as FSD-X offers it.",
      "It also includes the <strong>NinjaTrader version of Knightfall when it launches</strong>. It has been approved by NinjaTrader and is <strong>scheduled for release on October 23, 2026</strong>. If that date moves, we'll post the new one.",
      "It <strong>does not include</strong> new products or tools released after your purchase.",
      "TradingView access is granted to the <strong>one TradingView username</strong> you enter at checkout. Access is limited to <strong>one person</strong>; sharing, reselling, or redistributing it ends access without refund.",
      "All FSD-X software is <strong>educational, rules-based software — not financial advice</strong> and not a trade-signal service. Trading involves <strong>substantial risk</strong>; you can lose some or all of your capital. No result is guaranteed.",
      "The Auto-Trader <strong>emits automation alerts only — it does not place or guarantee any order</strong>. Execution runs through third-party services and brokers <strong>you</strong> choose and control, and you are responsible for your own safeguards and for confirming automation is allowed by your broker and prop firm.",
      "I have read and agree to the full <a href='disclosures.html#lifetime' target='_blank' rel='noopener' class='text-green-400 underline hover:text-green-300'>Disclosures &amp; Terms of Service</a>, including the Auto-Trader Addendum and the Lifetime terms."
    ],
    agree: "I understand this is a one-time, non-refundable payment with no trial, I accept the FSD-X Lifetime Terms, and I take full responsibility for all activity, losses, and outcomes on my own account.",
    proceed: "Proceed to Checkout"
  };

  // Every VIP data-gate value resolves to the same unified terms (one plan →
  // one gate). Nightwing and Raven are the two products that are genuinely
  // different, and each needs its own terms for the same reason.
  var TERMS = {
    membership: UNIFIED, tools: UNIFIED, autotrader: UNIFIED,
    nightwing: NIGHTWING, raven: RAVEN, lifetime: LIFETIME, ntsolo: NTSOLO
  };

  var pendingUrl = null;
  var pendingTarget = "_blank";
  var pendingGate = "membership";

  // ---- build modal once ----
  function buildModal() {
    var wrap = document.createElement("div");
    wrap.id = "fsdx-gate";
    wrap.setAttribute("aria-hidden", "true");
    wrap.style.cssText =
      "position:fixed;inset:0;z-index:9999;display:none;align-items:center;justify-content:center;" +
      "background:rgba(0,0,0,.8);backdrop-filter:blur(4px);padding:1rem;";
    wrap.innerHTML =
      '<div role="dialog" aria-modal="true" aria-labelledby="fsdx-gate-title" ' +
      'style="background:#09090b;border:1px solid rgba(255,255,255,.12);border-radius:1rem;' +
      'max-width:34rem;width:100%;max-height:90vh;overflow-y:auto;box-shadow:0 20px 60px rgba(0,0,0,.6);">' +
        '<div style="padding:1.5rem 1.5rem 1.25rem;">' +
          '<div id="fsdx-gate-eyebrow" style="color:#34d399;font-size:10px;letter-spacing:.25em;text-transform:uppercase;font-weight:700;margin-bottom:.5rem;"></div>' +
          '<h2 id="fsdx-gate-title" style="font-size:1.15rem;font-weight:800;color:#fff;margin:0 0 1rem;line-height:1.3;"></h2>' +
          '<ul id="fsdx-gate-points" style="list-style:disc;padding-left:1.1rem;margin:0 0 1.25rem;display:flex;flex-direction:column;gap:.6rem;color:#a1a1aa;font-size:.82rem;line-height:1.5;"></ul>' +
          '<label style="display:flex;align-items:flex-start;gap:.6rem;cursor:pointer;user-select:none;background:rgba(255,255,255,.03);border:1px solid rgba(255,255,255,.08);border-radius:.75rem;padding:.75rem .9rem;">' +
            '<input type="checkbox" id="fsdx-gate-check" style="width:1.1rem;height:1.1rem;margin-top:.1rem;accent-color:#22c55e;flex:0 0 auto;cursor:pointer;">' +
            '<span id="fsdx-gate-agree" style="color:#e4e4e7;font-size:.82rem;line-height:1.45;font-weight:600;"></span>' +
          '</label>' +
          '<div style="display:flex;gap:.75rem;margin-top:1.25rem;">' +
            '<button id="fsdx-gate-cancel" type="button" ' +
              'style="flex:0 0 auto;border:1px solid rgba(255,255,255,.2);background:transparent;color:#fff;font-weight:600;padding:.75rem 1.25rem;border-radius:.85rem;cursor:pointer;">Cancel</button>' +
            '<button id="fsdx-gate-proceed" type="button" disabled ' +
              'style="flex:1;background:#22c55e;color:#000;font-weight:800;padding:.75rem 1.25rem;border-radius:.85rem;cursor:not-allowed;opacity:.5;transition:opacity .15s;"></button>' +
          '</div>' +
        '</div>' +
      '</div>';
    document.body.appendChild(wrap);

    var check = wrap.querySelector("#fsdx-gate-check");
    var proceed = wrap.querySelector("#fsdx-gate-proceed");
    var cancel = wrap.querySelector("#fsdx-gate-cancel");

    check.addEventListener("change", function () {
      proceed.disabled = !check.checked;
      proceed.style.cursor = check.checked ? "pointer" : "not-allowed";
      proceed.style.opacity = check.checked ? "1" : ".5";
    });
    cancel.addEventListener("click", closeModal);
    wrap.addEventListener("click", function (e) { if (e.target === wrap) closeModal(); });
    document.addEventListener("keydown", function (e) {
      if (e.key === "Escape" && wrap.style.display === "flex") closeModal();
    });
    proceed.addEventListener("click", function () {
      if (!check.checked || !pendingUrl) return;
      var url = pendingUrl;
      var tgt = pendingTarget;
      trackCheckoutStart(pendingGate);   // record checkout intent before we send them to Whop
      closeModal();
      if (tgt === "_blank") { window.open(url, "_blank", "noopener"); }
      else { window.location.href = url; }
    });

    return wrap;
  }

  function openModal(variant) {
    var t = TERMS[variant] || TERMS.membership;
    var wrap = document.getElementById("fsdx-gate") || buildModal();
    wrap.querySelector("#fsdx-gate-eyebrow").textContent = t.eyebrow;
    wrap.querySelector("#fsdx-gate-title").textContent = t.title;
    wrap.querySelector("#fsdx-gate-agree").textContent = t.agree;
    var ul = wrap.querySelector("#fsdx-gate-points");
    ul.innerHTML = t.points.map(function (p) { return "<li>" + p + "</li>"; }).join("");
    var proceed = wrap.querySelector("#fsdx-gate-proceed");
    proceed.textContent = t.proceed;
    var check = wrap.querySelector("#fsdx-gate-check");
    check.checked = false;
    proceed.disabled = true;
    proceed.style.cursor = "not-allowed";
    proceed.style.opacity = ".5";
    wrap.style.display = "flex";
    wrap.setAttribute("aria-hidden", "false");
    document.body.style.overflow = "hidden";
  }

  function closeModal() {
    var wrap = document.getElementById("fsdx-gate");
    if (!wrap) return;
    wrap.style.display = "none";
    wrap.setAttribute("aria-hidden", "true");
    document.body.style.overflow = "";
    pendingUrl = null;
  }

  // ---- intercept checkout clicks (delegated; covers future buttons too) ----
  document.addEventListener("click", function (e) {
    var a = e.target.closest && e.target.closest('a[href*="whop.com/checkout"]');
    if (!a) return;
    e.preventDefault();
    pendingUrl = a.getAttribute("href");
    pendingTarget = a.getAttribute("target") || "_self";
    pendingGate = a.getAttribute("data-gate") || "membership";
    openModal(pendingGate);
  }, true);

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", buildModal);
  } else {
    buildModal();
  }
})();
